package javaapplication11;

import java.util.ArrayList;
import java.util.Scanner;
import classes.*;

public class JavaApplication11 {

    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Pessoa> pessoas = new ArrayList<Pessoa>();

        int opcao = 0;
        while (opcao != 7) {
            System.out.println("Selecione uma opção:");
            System.out.println("1 - Inserir Disciplina");
            System.out.println("2 - Inserir Professor");
            System.out.println("3 - Inserir Atendente");
            System.out.println("4 - Inserir Aluno");
            System.out.println("5 - Adicionar Disciplina ao Professor");
            System.out.println("6 - Mostrar Pessoas");
            System.out.println("7 - Sair");

            opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1:
                    System.out.println("Digite o código da disciplina:");
                    int codigo = scanner.nextInt();
                    scanner.nextLine();

                    System.out.println("Digite o nome da disciplina:");
                    String nome = scanner.nextLine();

                    Disciplina disciplina = new Disciplina(codigo, nome);
                    System.out.println("Disciplina inserida com sucesso.");
                    break;
                case 2:
                    System.out.println("Digite o nome do professor:");
                    String nomeProfessor = scanner.nextLine();

                    System.out.println("Digite o CPF do professor:");
                    String cpfProfessor = scanner.nextLine();

                    System.out.println("Digite a URL do currículo Lattes do professor:");
                    String urlCurriculoLattes = scanner.nextLine();

                    Professor professor = new Professor(nomeProfessor, cpfProfessor, urlCurriculoLattes);
                    pessoas.add(professor);
                    System.out.println("Professor inserido com sucesso.");
                    break;
                case 3:
                    System.out.println("Digite o nome do atendente:");
                    String nomeAtendente = scanner.nextLine();

                    System.out.println("Digite o CPF do atendente:");
                    String cpfAtendente = scanner.nextLine();

                    System.out.println("Digite o setor do atendente:");
                    String setor = scanner.nextLine();

                    System.out.println("Digite a função do atendente:");
                    String funcao = scanner.nextLine();

                    Atendente atendente = new Atendente(nomeAtendente, cpfAtendente, setor, funcao);
                    pessoas.add(atendente);
                    System.out.println("Atendente inserido com sucesso.");
                    break;
                case 4:
                    System.out.println("Digite o nome do aluno:");
                    String nomeAluno = scanner.nextLine();

                    System.out.println("Digite o CPF do aluno:");
                    String cpfAluno = scanner.nextLine();

                    System.out.println("Digite o RA do aluno:");
                    String ra = scanner.nextLine();

                    System.out.println("Digite o curso do aluno:");
                    String curso = scanner.nextLine();

                    Aluno aluno = new Aluno(nomeAluno, cpfAluno, ra, curso);
                    pessoas.add(aluno);
                    System.out.println("Aluno inserido com sucesso.");
                    break;
                case 5:
                    if (pessoas.size() == 0) {
                        System.out.println("Não há professores cadastrados.");
                    } else {
                        System.out.println("Selecione um professor:");
                        for (int i = 0; i < pessoas.size(); i++) {
                            if (pessoas.get(i) instanceof Professor) {
                                System.out.println((i + 1) + " - " + pessoas.get(i).getNome());
                                int opcaoProfessor = scanner.nextInt();
                    scanner.nextLine();

                    if (opcaoProfessor < 1 || opcaoProfessor > pessoas.size()) {
                        System.out.println("Opção inválida.");
                    } else {
                        Professor professorSelecionado = (Professor) pessoas.get(opcaoProfessor - 1);

                        System.out.println("Digite o código da disciplina:");
                        int codigoDisciplina = scanner.nextInt();
                        scanner.nextLine();

                        professorSelecionado.adicionarDisciplina(codigoDisciplina);
                        System.out.println("Disciplina adicionada ao professor " + professorSelecionado.getNome() + " com sucesso.");}}
                    }
                }
                break;
                case 6:
                    if (pessoas.size() == 0) {
                        System.out.println("Não há pessoas cadastradas.");
                    } else {
                        System.out.println("Pessoas cadastradas:");

                        for (Pessoa pessoa : pessoas) {
                            System.out.println(pessoa);
                        }
                    }
                    break;
                case 7:
                    System.out.println("Saindo...");
                    break;
                default:
                    System.out.println("Opção inválida.");
                    break;
            }
        }

        scanner.close();
    }
}