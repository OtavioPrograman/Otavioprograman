package classes;

import java.util.ArrayList;

public class Professor extends Pessoa {
    private String urlCurriculoLattes;
    private ArrayList<Disciplina> disciplinas;

    public Professor() {}

    public Professor(String nome, String cpf, String urlCurriculoLattes) {
        super(nome, cpf);
        this.urlCurriculoLattes = urlCurriculoLattes;
        this.disciplinas = new ArrayList<Disciplina>();
    }

    public void addDisciplina(Disciplina disciplina) {
        disciplinas.add(disciplina);
    }

    public void removeDisciplina(int index) {
        disciplinas.remove(index);
    }

    public void removeDisciplina(Disciplina disciplina) {
        disciplinas.remove(disciplina);
    }

    public Disciplina getDisciplina(int index) {
        return disciplinas.get(index);
    }

    public String getUrlCurriculoLattes() {
        return urlCurriculoLattes;
    }

    public void setUrlCurriculoLattes(String urlCurriculoLattes) {
        this.urlCurriculoLattes = urlCurriculoLattes;
    }

    public ArrayList<Disciplina> getDisciplinas() {
        return disciplinas;
    }

    public void setDisciplinas(ArrayList<Disciplina> disciplinas) {
        this.disciplinas = disciplinas;
    }
    
    public void adicionarDisciplina(int adicionarDisciplina) {
        this.disciplinas = disciplinas;
    }

    @Override
    public String toString() {
        String disciplinasStr = "Disciplinas: ";
        for (Disciplina disciplina : disciplinas) {
            disciplinasStr += "\n" + disciplina.toString();
        }

        return super.toString() + "\nURL do currículo Lattes: " + urlCurriculoLattes + "\n" + disciplinasStr;
    }

    
}