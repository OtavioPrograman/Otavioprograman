package classes;

public class FuncionarioHorista extends Funcionario {
    private int qtdeHoras;
    private double valorHora;
    
    public FuncionarioHorista() {
    }
    
    public FuncionarioHorista(int numeroCracha, String nome, String setor, String funcao, int qtdeHoras, double valorHora) {
        super(numeroCracha, nome, setor, funcao);
        this.qtdeHoras = qtdeHoras;
        this.valorHora = valorHora;
    }
    
    //getters e setters
    public int getQtdeHoras() {
        return qtdeHoras;
    }
    public void setQtdeHoras(int qtdeHoras) {
        this.qtdeHoras = qtdeHoras;
    }
    public double getValorHora() {
        return valorHora;
    }
    public void setValorHora(double valorHora) {
        this.valorHora = valorHora;
    }
    
    //método imprimir
    public String imprimir() {
        return "Funcionário Horista:\n" +
                "Número do Crachá: " + getNumeroCracha() + "\n" +
                "Nome: " + getNome() + "\n" +
                "Setor: " + getSetor() + "\n" +
                "Função: " + getFuncao() + "\n" +
                "Quantidade de Horas: " + qtdeHoras + "\n" +
                "Valor da Hora: R$" + valorHora + "\n";
    }
}