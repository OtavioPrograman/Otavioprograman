package empresa;

import java.util.ArrayList;
import java.util.Scanner;
import classes.*;

public class Empresa {


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Funcionario> funcionarios = new ArrayList<Funcionario>();
        
        int opcao;
        do {
            System.out.println("Menu:");
            System.out.println("1 - Inserir Funcionário");
            System.out.println("2 - Exibir Funcionários");
            System.out.println("3 - Sair");
            System.out.print("Digite a opção desejada: ");
            opcao = sc.nextInt();
            
            switch (opcao) {
            case 1:
                System.out.println("Qual o tipo de funcionário?");
                System.out.println("1 - Horista");
                System.out.println("2 - Mensalista");
                int tipoFuncionario = sc.nextInt();
                
                System.out.print("Número do Crachá: ");
                int numeroCracha = sc.nextInt();
                System.out.print("Nome: ");
                String nome = sc.next();
                System.out.print("Setor: ");
                String setor = sc.next();
                System.out.print("Função: ");
                String funcao = sc.next();
                
                if (tipoFuncionario == 1) {
                    System.out.print("Quantidade de horas trabalhadas: ");
                    int qtdeHoras = sc.nextInt();
                    System.out.print("Valor da hora: ");
                    double valorHora = sc.nextDouble();
                    
                    FuncionarioHorista fh = new FuncionarioHorista(numeroCracha, nome, setor, funcao, qtdeHoras, valorHora);
                    funcionarios.add(fh);
                } else if (tipoFuncionario == 2) {
                    System.out.print("Salário: ");
                    double salario = sc.nextDouble();
                    
                    FuncionarioMensalista fm = new FuncionarioMensalista(numeroCracha, nome, setor, funcao, salario);
                    funcionarios.add(fm);
                } else {
                    System.out.println("Opção inválida!");
                }
                break;
            case 2:
                System.out.println("Funcionários:");
                for (Funcionario f : funcionarios) {
                    if (f instanceof FuncionarioHorista) {
                        System.out.println(((FuncionarioHorista) f).imprimir());
                    } else if (f instanceof FuncionarioMensalista) {
                        System.out.println(((FuncionarioMensalista) f).imprimir());
                    } else {
                        System.out.println("Funcionário inválido!");
                    }
                }
                break;
            case 3:
                System.out.println("Programa encerrado!");
                break;
            default:
                System.out.println("Opção inválida!");
                break;
            }
        } while (opcao != 3);
        
        sc.close();
    }
}